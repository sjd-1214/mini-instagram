#include <iostream>
#include <string>
#include "instagram.h"
using namespace std;
int main()
{
    Instagram *instagram = new Instagram();
    instagram->showMenu();
    return 0;
}