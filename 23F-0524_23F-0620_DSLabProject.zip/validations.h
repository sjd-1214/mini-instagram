#pragma once
#include <iostream>
using namespace std;
bool validateusername(string username);
bool validate_strong_password(string password);
bool validate_email(string email);
bool validate_DOB(string dob);